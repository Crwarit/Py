# if True:    # Defalut as True value
#     print("It's true!")
    
hungry = False
if hungry:  # Or if gungry == true
    print("FEED ME!")
else:
    print("I'm FULL!")