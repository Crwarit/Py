myList = [(1,2),(3,4),(5,6),(7,8)]

for i in myList:
    print(i)
    
for (a,b) in myList:
    print(a)
    print(b)
    
d = {"k1": 1, "k2": 2, "k3": 3}

# Note: .items() select all from d
# Note: .values() select value from d
# Note: .keys() select key from d (DEFAULT)
for i in d.keys():
    print(i)
    
for i in "Hello World":
    print("Cool!")