############ Similar to Dict but immutability (UNABLE to reassign) ############
tuples = (1, 2, 3)
lists = [1, 2, 3]

print(type(tuples))     # Check class type
print(type(lists))      # Check class type
print(len(tuples))      # len()

tuples2 = ("one", 2)
print(tuples2[1])

############ Tuple has only 2 methods that is count() and index() ############
tuples3 = ("a", "a", "b")
print(tuples3.count("a"))   # Count "a" in tuples3
print(tuples3.count("b"))   # Count "b" in tuples3
print(tuples3.index("a"))   # Result the very first time appear
print(tuples3.index("b"))   # Result the very first time appear
