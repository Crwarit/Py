# myFile = open("08IOFile.txt")       # Note: pwd for the current directory C:\\Users\\USER\\Desktop\\Py\\08IOFile.txt
# content = myFile.read()
# linelist = myFile.readlines()       # Note: .readlines() willread each line into list
# print(linelist)
# myFile.close()
##############################################################################################################################
with open("08IOFile.txt") as myNewFIle:
    content = myNewFIle.read()
    lineList = myNewFIle.readlines()
##############################################################################################################################
# Note: mode=r(read) w(overwrite) a(append to the end) r+(read and write) w+(write and read)
# Note: write a new file if file does not exist, overwrite if it exist
# Note: default as open(file, mode="r", buffering=-1, encoding=none, errors=none, newline=none, closefd=none, opener=none)

with open("08IOFile.txt", mode="a") as myNewFile:      # Note: Append
    myNewFile.write("\nFOUR ON FOURTH")
    
with open("08IOFile.txt") as myNewFile:
    content = myNewFile.read()
    lineList = myNewFile.readlines()
    print(content)
    
with open("08IOFile.txt", "w") as myNewFile2:
    myNewFile2.write("I created this file.")
    
with open("08IOFile2.txt") as myNewFile2:
    print(myNewFile2.read())