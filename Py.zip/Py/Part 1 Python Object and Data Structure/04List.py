# combineList = ["String", 1, 1.2]
# print(len(combineList))

intList = [1, 2, 3]
intList2 = [4, 5, 6]
print(intList + intList2)
newList = intList + intList2

newList[0] = "ONE ALL CAPS"
print(newList)

newList.append(7)
newList.append("EIGHT ALL CAPS")
print(newList)

poppedItem1 = newList.pop()   # .pop is to remove the last item in list
poppedItem2 = newList.pop(0)  # Remove specific index
print(poppedItem1)            # print the removed item
print(poppedItem2)
print(newList)

############# .sort() = low to high / .reverse() = high to low #############

strList = ["a", "c", "b", "e", "d"]
numList = [5, 4, 2, 3, 1]
strList.sort()
numList.sort()
print(strList)
print(numList)

strList.reverse()
numList.reverse()
print(strList)
print(numList)

nestedList = [1, 2, [3, 4]]
# If I want to print 3
print(nestedList[2][0])