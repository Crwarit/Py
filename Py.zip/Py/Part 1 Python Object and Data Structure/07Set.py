########################## It has to be UNIQUE value in there ##########################
mySet = set()

mySet.add(1)
print(mySet)

mySet.add(2)
mySet.add(2)    # Unable to add duplicate value
print(mySet)

myList = [1,1,1,2,2,2,3,3,3]
print(set(myList))      # Remove duplicate value
