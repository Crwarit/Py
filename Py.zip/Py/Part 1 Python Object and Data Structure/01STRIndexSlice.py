mystring = "ABCDEFGHIJK"

print(mystring[2])      # Select index[2]
print(mystring[2:])     # Select from index[2] until end
print(mystring[2:6])    # Select from [2] to [5] ([6] is Not INCLUDED)
print(mystring[:6])     # Select str until [5]
print(mystring[::2])    # Jump 2
print(mystring[2:7:2])  # Select str from [2] to [6] and jump 2
print(mystring[::-1])   # Select backward  

# ! This function is critical
# ? Should we optimize this query?
# * This feature will be removed in v2.0
# // Highlight this block of code
# This is a standard comment
# Note: Implement the login function
