############ {"key1": "value1", "key2", "value2"} ############
############ Dict retrieve by key name / List retrieve by index seq ############

# pricesLookup = {"Apple": 2.99, "Orange": 1.99, "Banana": 0.99}
# print(pricesLookup["Apple"])

# variousDict = {"k1": 123, "k2": [0, 1, 2], "k3": {"insideKey": 100}}
# print(variousDict["k1"])
# print(variousDict["k2"][1])
# print(variousDict["k3"]["insideKey"])

# d1 = {"key1": ["a", "b", "c"]}
# print(d1["key1"][2].upper())

# d2 = {"k1": 100, "k2": 200}
# d2["k3"] = 300              # Add k3 into dict
# d2["k1"] = "NEW VALUE"      # Edit value in k1
# print(d2)

# d3 = {'k1': 'NEW VALUE', 'k2': 200, 'k3': 300}
# print(d3.keys())            # Print only key
# print(d3.values())          # Print only value
# print(d3.items())           # Print into tuple

d4 = {"k1": [{"nest_key": ["this is deep", ["hello"]]}]}
print(d4["k1"][0]["nest_key"][1][0])

d5 = {"k1": [1, 2, {"k2": ["this is tricky", {"tough": [1, 2, ["hello"]]}]}]}
print(d5["k1"][2]["k2"][1]["tough"][2][0])