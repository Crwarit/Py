name = "Bew"
lastLetters = name[1:]

print("L" + lastLetters)

letter = "z"
print(letter * 10)

x = "Hello World"
print(x.upper())
print(x.lower())
print(x.split())    # Split into list by space
y = "Hi this is a string"
print(y.split("i")) # Split with "i"