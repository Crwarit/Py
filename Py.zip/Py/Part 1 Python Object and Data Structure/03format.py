################ String ################

print("This is a string {}".format("INSERTED"))

print("The {2} {1} {0}".format("fox", "brown", "quick"))

print("The {q} {b} {f}".format(f="fox", b="brown", q="quick"))

################ Float ################
# {value:width.precisionf}
# width = total of the value, if width more than the value, it will add space
# precisionf = number of float digit

result = 100.12345
print("The result is {r:10.5f}".format(r=result))

################ THE BEST WAY TO USE format ################

name = "Bew"
age = 23
print(f"{name} is {age} years old.")
