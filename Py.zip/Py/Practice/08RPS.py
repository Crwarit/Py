import random

# botChoice = ["Rock", "Paper", "Scissor"]
# botChoose = random.choice(botChoice)
# playerChoice = input("What would you choose? Rock, Paper or Scissor: ")
# print(f"Bot choose {botChoose}")

# if playerChoice == botChoose:
#     print("DRAW!")
# elif playerChoice == "Rock" and botChoose == "Paper":
#     print("You Lose!")
# elif playerChoice == "Rock" and botChoose == "Scissor":
#     print("You Win!")
# elif playerChoice == "Paper" and botChoose == "Rock":
#     print("You Win!")
# elif playerChoice == "Paper" and botChoose == "Scissor":
#     print("You Lose!")
# elif playerChoice == "Scissor" and botChoose == "Paper":
#     print("You Win!")
# elif playerChoice == "Scissor" and botChoose == "Rock":
#     print("You Lose!")

botChoice = ["rock", "paper", "scissor"]
botChoose = random.choice(botChoice)
while True:
    playerChoice = input("What would you choose? Rock, Paper or Scissor: ").lower()
    while playerChoice not in botChoice:
        playerChoice = input("Please type Rock, Paper or Scissor: ").lower()
        if playerChoice in botChoice:
            print(f"You choose {playerChoice} and Bot choose {botChoose}")
            break
        
    if playerChoice == botChoose:
        print("DRAW!")
    elif playerChoice == "rock" and botChoose == "paper":
        print("You Lose!")
    elif playerChoice == "rock" and botChoose == "scissor":
        print("You Win!")
    elif playerChoice == "paper" and botChoose == "rock":
        print("You Win!")
    elif playerChoice == "paper" and botChoose == "scissor":
        print("You Lose!")
    elif playerChoice == "scissor" and botChoose == "paper":
        print("You Win!")
    elif playerChoice == "scissor" and botChoose == "rock":
        print("You Lose!")
    
    restart = input("Wanna play again? (Y) or (N): ")
    if restart == "Y":
        continue
    else:
        print("Thanks foy playing!")
        break