import random

while True:
    # Generate a random number between 1 and 9
    num = range(1, 10)
    randNum = random.choice(num)

    # Ask the user to guess
    guess = int(input("Guess the number between 1-9: "))
    while guess not in num:
        guess = int(input("Please enter a number between 1-9: "))

    # Loop to check guesses
    while True:
        if guess > randNum:
            print("Too high!")
            guess = int(input("Try again!: "))
        elif guess < randNum:
            print("Too low!")
            guess = int(input("Try again!: "))
        else:
            print(f"You win! The number is {randNum}")
            break

    # Ask if the player wants to restart the game
    restart = input("Wanna play again? (Y) or (N): ").strip().upper()
    if restart == "Y":
        continue
    else:
        print("Thanks for playing!")
        break