word = input("Type your word here: ")
if word == word[::-1]:  # Compare the string with its reverse
    print(f"{word} is a palindrome!")
else:
    print(f"{word} is not a palindrome.")
