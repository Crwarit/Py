
# Note: Create a program that asks the user to enter their name and their age. Print out a message addressed to them that tells them the year that they will turn 100 years old.

name = input("What is your name?: ")
age = int(input("How old are you?: "))
ageRemain = 100 - age

print(f"Hello {name}, you have {ageRemain} years left to become 100 years old")