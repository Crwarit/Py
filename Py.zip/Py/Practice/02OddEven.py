num = int(input("Type your number here: "))

if num % 2 == 0:
    print("This is EVEN number!")
else:
    print("This is ODD number!")