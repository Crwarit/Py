
# Note: == mean compare exact value
"hello" == "Hello"  # False
"hello" == "hello"  # True
"2" == 2            # False
2.0 == 2            # True

# Note: =! mean NOT equal to
# Note: < > <= >=